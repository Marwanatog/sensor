# -*- coding: utf-8 -*-
# Part of p2p. See LICENSE file for full copyright and licensing details.

{
    'name': 'Diesel Sensor',
    'version': '1.2',
    'category': 'Sales',
    'sequence': 60,
    'summary': 'Sales',
    'description': "",
    'website': 'https://www.p2p.com/page/purchase',
    'depends': ['base'],
    'data': [

        'data/diesel_sensor_data.xml',

        'security/ir.model.access.csv',

        'views/diesel_sensor_views.xml',


    ],
    'demo': [

    ],
    'installable': True,
    'auto_install': False,
    'application': True,
}
