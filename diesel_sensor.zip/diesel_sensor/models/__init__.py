# -*- coding: utf-8 -*-
# Part of p2p. See LICENSE file for full copyright and licensing details.


from . import diesel_sensor

