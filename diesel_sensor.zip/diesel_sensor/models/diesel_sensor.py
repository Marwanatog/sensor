
class DieselSensor(models.Model):
    _name = "diesel.sensor"
    _description = "diesel sensor"
    _order = 'id desc'

    name = fields.Char('Name')
    date=fields.Date(string='Date')
    value=fields.Char('Driver Phone')
    qty = fields.Char('qty')
    location_id=fields.Many2one('stock.location','Location')
